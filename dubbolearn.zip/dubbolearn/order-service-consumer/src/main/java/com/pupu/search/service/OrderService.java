package com.pupu.search.service;

public interface OrderService {
    /**
     * 初始化订单
     * @param userId
     */
    public void initOrder(String userId);
}
